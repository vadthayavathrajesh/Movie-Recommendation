# movie_recommendation_using_CountV
Created a Recommendation System Using vectorization and found the similar movies using Cosine similarity
